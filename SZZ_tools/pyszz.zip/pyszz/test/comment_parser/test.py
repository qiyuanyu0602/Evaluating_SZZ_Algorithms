import os
""" multi """

def test():
    """
    aaaaa
    bsdaads
    casdas
    :param asdasd
    """
    # comment
    test = list()

    """"'
    aaaaa
    """''

 # comment
 # comment
 # comment

print("asda#\ns")

'''
test tes'''